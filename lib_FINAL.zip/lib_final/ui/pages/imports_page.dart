import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/providers.dart';
import '../../models/models.dart';

class ImportsPage extends ConsumerWidget {
  const ImportsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final importsAsync = ref.watch(importsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Bottle Imports'),
        centerTitle: true,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: IconButton(
              onPressed: () => _showAddImportDialog(context, ref),
              tooltip: 'Add new import',
              icon: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.add, color: Colors.white, size: 24),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => _showAddImportDialog(context, ref),
                icon: const Icon(Icons.add_circle),
                label: const Text('Add New Import'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: Theme.of(context).primaryColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: importsAsync.when(
              data: (imports) {
                if (imports.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.local_shipping_outlined, size: 64, color: Colors.grey[300]),
                        const SizedBox(height: 16),
                        const Text(
                          'No imports recorded yet',
                          style: TextStyle(color: Colors.grey, fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: imports.length,
                  itemBuilder: (context, index) {
                    final imp = imports[index];
                    return _buildImportCard(context, ref, imp);
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => Center(child: Text('Error: $err')),
            ),
          ),
          const SizedBox(height: 100),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddImportDialog(context, ref),
        tooltip: 'Add import',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildImportCard(BuildContext context, WidgetRef ref, BottleImport imp) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(imp.supplierName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text(DateFormat('dd MMM yyyy').format(imp.date), style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
                Text('Rs. ${imp.totalCost.toStringAsFixed(0)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue)),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Theme.of(context).scaffoldBackgroundColor, borderRadius: BorderRadius.circular(12)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildInlineStat('Small', imp.smallBottleQty.toString()),
                  _buildInlineStat('Large', imp.largeBottleQty.toString()),
                  _buildInlineStat('Extra', 'Rs. ${imp.extraCharges.toStringAsFixed(0)}'),
                ],
              ),
            ),
            if (imp.description != null && imp.description!.isNotEmpty) ...[
              const SizedBox(height: 12),
              Align(alignment: Alignment.centerLeft, child: Text(imp.description!, style: const TextStyle(fontSize: 12))),
            ],
            const Divider(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () => _showAddImportDialog(context, ref, imp: imp),
                  icon: const Icon(Icons.edit, size: 16),
                  label: const Text('Edit'),
                ),
                TextButton.icon(
                  onPressed: () => _deleteImport(context, ref, imp.id),
                  icon: const Icon(Icons.delete, size: 16, color: Colors.red),
                  label: const Text('Delete', style: TextStyle(color: Colors.red)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInlineStat(String label, String value) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
        Text(value, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Future<void> _showAddImportDialog(BuildContext context, WidgetRef ref, {BottleImport? imp}) async {
    final supplierController = TextEditingController(text: imp?.supplierName);
    final smallQtyController = TextEditingController(text: imp?.smallBottleQty.toString() ?? '0');
    final smallCostController = TextEditingController(text: imp?.smallBottleCost.toString() ?? '0');
    final largeQtyController = TextEditingController(text: imp?.largeBottleQty.toString() ?? '0');
    final largeCostController = TextEditingController(text: imp?.largeBottleCost.toString() ?? '0');
    final extraChargesController = TextEditingController(text: imp?.extraCharges.toString() ?? '0');
    final descriptionController = TextEditingController(text: imp?.description);
    DateTime selectedDate = imp?.date ?? DateTime.now();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => StatefulBuilder(
        builder: (context, setModalState) {
          double calculateTotal() {
            final sQty = int.tryParse(smallQtyController.text) ?? 0;
            final sCost = double.tryParse(smallCostController.text) ?? 0.0;
            final lQty = int.tryParse(largeQtyController.text) ?? 0;
            final lCost = double.tryParse(largeCostController.text) ?? 0.0;
            final extra = double.tryParse(extraChargesController.text) ?? 0.0;
            return (sQty * sCost) + (lQty * lCost) + extra;
          }

          return Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(imp == null ? 'Add Import' : 'Edit Import', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  TextField(controller: supplierController, decoration: const InputDecoration(labelText: 'Supplier Name', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: TextField(controller: smallQtyController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Small Qty', border: OutlineInputBorder()), onChanged: (_) => setModalState(() {}))),
                      const SizedBox(width: 8),
                      Expanded(child: TextField(controller: smallCostController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cost/Small', border: OutlineInputBorder()), onChanged: (_) => setModalState(() {}))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: TextField(controller: largeQtyController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Large Qty', border: OutlineInputBorder()), onChanged: (_) => setModalState(() {}))),
                      const SizedBox(width: 8),
                      Expanded(child: TextField(controller: largeCostController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cost/Large', border: OutlineInputBorder()), onChanged: (_) => setModalState(() {}))),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(controller: extraChargesController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Extra Charges', border: OutlineInputBorder()), onChanged: (_) => setModalState(() {})),
                  const SizedBox(height: 12),
                  TextField(controller: descriptionController, decoration: const InputDecoration(labelText: 'Description (Optional)', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  ListTile(
                    title: Text('Date: ${DateFormat('dd MMM yyyy').format(selectedDate)}'),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () async {
                      final date = await showDatePicker(context: context, initialDate: selectedDate, firstDate: DateTime(2020), lastDate: DateTime.now());
                      if (date != null) setModalState(() => selectedDate = date);
                    },
                  ),
                  const Divider(),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total Cost:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        Text('Rs. ${calculateTotal().toStringAsFixed(0)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.blue)),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        if (supplierController.text.isEmpty) return;
                        final isar = ref.read(isarProvider);
                        final dbService = ref.read(databaseServiceProvider);
                        
                        // FIXED: Transaction only for database write
                        await isar.writeTxn(() async {
                          final currentImport = imp ?? BottleImport();
                          currentImport
                            ..supplierName = supplierController.text
                            ..smallBottleQty = int.tryParse(smallQtyController.text) ?? 0
                            ..smallBottleCost = double.tryParse(smallCostController.text) ?? 0.0
                            ..largeBottleQty = int.tryParse(largeQtyController.text) ?? 0
                            ..largeBottleCost = double.tryParse(largeCostController.text) ?? 0.0
                            ..extraCharges = double.tryParse(extraChargesController.text) ?? 0.0
                            ..totalCost = calculateTotal()
                            ..description = descriptionController.text
                            ..date = selectedDate;
                          
                          await isar.collection<BottleImport>().put(currentImport);
                        });
                        
                        await dbService.logActivity('${imp == null ? "Added" : "Updated"} import from ${supplierController.text}');
                        
                        if (context.mounted) Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white, padding: const EdgeInsets.all(16)),
                      child: const Text('Save Import'),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _deleteImport(BuildContext context, WidgetRef ref, int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Import?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete', style: TextStyle(color: Colors.red))),
        ],
      ),
    );

    if (confirm == true) {
      final isar = ref.read(isarProvider);
      final dbService = ref.read(databaseServiceProvider);
      
      // FIXED: Get import BEFORE transaction
      final imp = await isar.collection<BottleImport>().get(id);
      
      // FIXED: Transaction only for delete
      await isar.writeTxn(() async {
        if (imp != null) {
          await isar.collection<BottleImport>().delete(id);
        }
      });
      
      // FIXED: Activity log OUTSIDE the transaction
      if (imp != null) {
        await dbService.logActivity('Deleted import from ${imp.supplierName}');
      }
    }
  }
}
